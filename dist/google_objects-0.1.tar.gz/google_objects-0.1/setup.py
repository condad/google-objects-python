from distutils.core import setup

setup(
    name='google_objects',
    packages=['google_objects'], # this must be the same as the name above
    version='0.1',
    description='A simple OO wrapper around google\'s python API client',
    author='Connor Sullivan',
    author_email='sully4792@gmail.com',
    url='https://github.com/theconnor/google-objects', # use the URL to the github repo
    download_url='https://github.com/theconnor/google-objects/tarball/0.1', # I'll explain this in a second
    keywords=['google', 'api', 'wrapper'], # arbitrary keywords
    classifiers=[],
)
